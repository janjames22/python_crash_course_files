def add(numbers):
    return sum(numbers)

def subtract(numbers):
    answer = numbers[0]
    for num in numbers[1:]:
        answer -= num
    return answer

def multiplication(numbers):
    answer = 1
    for num in numbers:
        answer *= num
    return answer

def divide(numbers):
    if len(numbers) == 0:
        return "Error: No numbers provided"
    answer = numbers[0]
    for num in numbers[1:]:
        if num == 0:
            #Print error instead of returning to prevent unreachable code
            print("Warning: Division by zero is now allowed. Skipping this number.")
            continue #Skip this number if number is zero
        answer /= num
    return answer

def get_numbers():
    numbers = []

    while True:
        try:
            number = float(input("Enter a number (or type 'done' to finish): "))
            numbers.append(number)
        except ValueError:
            choice = input("Type 'done' if you finished entering numbers or press Enter to continue: ").strip().lower()
            if choice == 'done':
                break
            else:
                print("Invalid input. Please enter a numeric value.")
    return numbers


        
def modified_calculator():
    while True:
        #Display available operations
        print("\nModified Simple Calculator")
        print("Choose an Operations:")
        print("1. Addition (+)")
        print("2. Subtraction (-)")
        print("3. Multiplication (*)")
        print("4. Division (/)")
        print("5. Exit")

        #Get the user's choice of operation
        operation = input("Enter your choice of operations (1/2/3/4/5): ")

        # check if the user wants to exit
        if operation == '5':
            print("Exiting the calculator! Goodbye")
            break

        # Input numbers
        print("Enter the numbers for the operations:")
        numbers = get_numbers()
        if not numbers:
            print("No numbers entered. Please try again.")
            continue
        
        #Perform the selected operation
        if operation == '1':
            answer = add(numbers)
            print(f"The result of addition is {answer}")
        elif operation == '2':
            answer = subtract(numbers)
            print(f"The result of subtraction is {answer}")
        elif operation == '3':
            answer = multiplication(numbers)
            print(f"The result of multiplication is {answer} ")
        elif operation == '4':
            answer = divide(numbers)
        else:
            print("Invalid choice. Please select a valid operation.")

# Run the calculator
modified_calculator()




