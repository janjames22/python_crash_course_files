def add(x, y):
    return x + y

def subtraction(x, y):
    return x - y

def multiplication(x, y):
    return x * y
def division(x, y):
    if y == 0:
        return "Error: Division by zero is not allowed."
    else:
        return x/y

def calculator():
    while True:
        print("\nSimple Calculator")
        print("Choose an operation:")
        print("1. Addition (+)")
        print("2. Subtraction (-)")
        print("3. Multiplication (*)")
        print("4. Division (/)")
        print("5. Exit")

        # Get the user's choice of operation
        operation = input("\nEnter your choice (1/2/3/4/5): \n")

        # the option 5 is the exit number
        if operation == '5':
            print("Exiting the calculator, Goodbye!")
            break
        
        # Input validation for operations (1 - 4)
        if operation not in ['1', '2', '3', '4']:
            print("Invalid input. Please select a valid operation.")
            continue

        # Get two numbers from the user
        try: 
            num1 = float(input("Enter the first number: "))
            num2 = float(input("Enter the second number: "))
        except ValueError:
            print("Error: Please enter numeric values only.")
            continue
        #Perform the selected operation
        if operation == '1':
            answer = add(num1, num2)
            print(f"The solution for {num1} + {num2} is {answer}")
        elif operation == '2':
            answer = subtraction(num1, num2)
            print(f"The solution for {num1} - {num2} is {answer}")
        elif operation == '3':
            answer = multiplication(num1, num2)
            print(f"The solution for {num1} * {num2} is {answer}")
        elif operation == '4':
            answer = division(num1, num2)
            print(f"The solution for {num1} /{ num2} is {answer}") 

# Run the calculator
calculator()


        
