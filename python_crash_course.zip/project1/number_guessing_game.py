
#import library for randomization of numbers.
import random 

#Write a function
def number_guessing_game():
    print("Welcome to the number guessing game!!!\n")

    #Let the user choose the range for the random number
    lower_bound = int(input("Enter the lower bound of the range: "))
    upper_bound =int(input("Enter the upper bound of the range: "))

    #generate random number
    secret_number = random.randint(lower_bound, upper_bound)

    #Monitor the number of attempts 
    n_attempts = 0

    while True:
        guess = int(input(f"Guess a number between {lower_bound} and {upper_bound}: "))
        n_attempts += 1

        if guess < secret_number:
            print("too low! Try again.")
        elif guess > secret_number:
            print("too high! Try again.")
        else:
            print(f"Congratulations, you guess the number {secret_number} correctly.")
            print(f"It took you {n_attempts} attempts.")
            break # Exit the loop when the user guesses correctly

# Start the game
number_guessing_game()