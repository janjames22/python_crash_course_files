import random

#Function to determine ther winner
def determine_the_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "tie"
    elif (user_choice == "rock" and computer_choice== "scissors") or \
         (user_choice == "scissors" and computer_choice== "paper") or \
         (user_choice == "paper" and computer_choice== "rock"):
        return "win"
    else:
        return "lose"
    

#Main Function
def play_game():
    #dictionary and a list to store the scores and choices: 
    scores = {"wins": 0, "losses": 0, "ties": 0 }
    choices = ["rock", "paper", "scissors"]

    while True:
        print("\nRock, Paper, Scissors - Let's Play!")
        print(f"Score -> Wins : {scores['wins']}, Losses: {scores['losses']}, Ties: {scores['ties']} ")

        #User input
        user_choice = input("Enter Rock, Paper, Scissors (or enter 'q' to quit): \n").lower()

        #Allow the user to quit the game
        if user_choice == 'q':
            break

        #Validate user input
        if user_choice not in choices:
            print("Invalid choice. Please choose Rock, Paper, or Scissors.")
            continue

        #Computer choice
        computer_choice = random.choice(choices)
        print(f"Computer Choise: {computer_choice.capitalize()}")

        #Determine the winner
        result = determine_the_winner(user_choice, computer_choice)

        if result == 'tie':
            print("It's a tie")
            scores['ties'] += 1
        elif result == 'win':
            print("You Win!")
            scores["wins"] += 1
        else:
            print("You lose!")
            scores["losses"] += 1
        
            
    
    print("\nFinal Score:")
    print(f"Wins: {scores['wins']}, Losses: {scores['losses']}, Ties: {scores['ties']} ")
    print("\nThank you for playing! ")

#Run the program
play_game()
