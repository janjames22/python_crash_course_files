# Initialize i = 1
def fizz_buzz():
    #Loop from number 1 to 100
    for i in range(1, 51):
        #check if the number is divisible by both 3 and 5
        if i % 3 == 0 and i % 5 == 0:
            print("FizzBuzz")
        #Check if the number is divisible only by 3
        elif i % 3 == 0:
            print("Fizz")
        #Check if the number is divisible only by 5
        elif i % 5 == 0:
            print("Buzz")
        else:
            print(i)

#Call the function
fizz_buzz()        
    