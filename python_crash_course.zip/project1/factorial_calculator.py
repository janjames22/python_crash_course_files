def factorial_recursive(n):
    """Calculate factorial using recursion."""
    if n == 0 or n == 1:
        return 1
    else:
        return n*factorial_recursive(n-1)
    
def factorial_iterative(n):
    """Calculate factorial using iteration."""
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


def main_calc():
    """Main function to handle user input and display the results."""
    while True:
        try:
            number = int(input("Enter a non-negative integer to calculate its factorial: "))
            if number < 0:
                print("Factorial is not defined for negative numbers. Please try ")
                continue
            break
        
        except ValueError:
            print("Invalid input. Please enter a valid integer.")
    
    # Calculate factorial using both methods
    fact_recursive = factorial_recursive(number)
    fact_iteration = factorial_iterative(number)

    #Display results
    print(f"The factorial of {number} using recursion is: {fact_recursive}")
    print(f"The factorial of {number} using iteration is: {fact_iteration}")

if __name__ == "__main__":
    main_calc()
