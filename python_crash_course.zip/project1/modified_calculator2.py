def add(numbers):
    return sum(numbers)

def subtract(numbers):
    result = numbers[0]
    for num in numbers[1:]:
        result -= num
    return result

def multiplication(numbers):
    result = 1 
    for num in numbers:
        result *= num
    return result

def divide(numbers):
    if len(numbers) == 0:
        return "Error: No numbers provided"
    result = numbers[0]
    for num in numbers[1:]:
        if num == 0:
            print("Warning: Division by zero is not allowed. Skipping this number.")
            continue # Skip this number if number is zero

        result /= num
    return result
    
def get_numbers():
    numbers = []

    while True:
        try:
            number = float(input("Enter a number (or type 'done' to finish): "))
            numbers.append(number)
        
        except ValueError:
            choice = input("Type 'done' if you finished entering numbers or press Enter to continue: ")
            if choice == 'done':
                break
            else: 
                print("Invalid input. Please enter a numeric value.")
    return numbers

def modified_calculator():
    while True:
        #Display available operations
        print("\nModified Simple Calculator")
        print("Choose an Operations: ")
        print("1. Addition (+)")
        print("2. Subtraction (-)")
        print("3. Multiplication (*)")
        print("4. Division (/)")
        print("5. Exit")

        # User input
        operation = input("Enter the type of operation you want to choose (1/2/3/4/5)\n")
        
        #Check if the user wants to exit
        if operation == '5':
            print("Exiting the calculator! Goodbye")
            break

        # Check if the input is valid before asking for numbers
        if operation not in ['1', '2', '3', '4', '5']:
            print("Invalid choice. Please selec a valid operation.")
            continue

        #Input numbers
        print("Enter the numbers for the operations to execute:")
        numbers = get_numbers()
        if not numbers:
            print("No numbers entered. Please try again.")
            continue

        
        #Perform the selected operation 
        if operation == '1':
            result = add(numbers)
            print(f"The result for addition is {result}")
        elif operation == '2':
            result = subtract(numbers)
            print(f"The result for subtraction is {result}.")
        elif operation == '3':
            result = multiplication(numbers)
            print(f"The result for multiplication is {result}.")
        elif operation == '4':
            result = divide(numbers)
            print(f"The result for subtraction is {result}.")
    

# Run the calculator
modified_calculator()

        