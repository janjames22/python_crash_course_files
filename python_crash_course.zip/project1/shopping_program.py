# Shopping List Program

def display_menu():
    print("\nShopping List Menu:")
    print("1. Add item")
    print("2. Remove item")
    print("3. Display List")
    print("4. Sort List Alphabetically")
    print("5. Exit")

def add_item(shopping_list):
    item = input("Enter the item to add: ")
    quantity = input("Enter how many items you want to add: ")

    # Adding item and quantity as a tuple to the list
    shopping_list.append((item, quantity))
    print(f"{quantity} of {item} has been added to the shopping list.") 

def remove_item(shopping_list):
    item_to_remove = input("Enter the name of the item to remove: ")

    # check if the item is in the list
    for i, (item, quantity) in enumerate(shopping_list):
        if item.lower() == item_to_remove.lower():
            del shopping_list[i]
            print(f"{item}: {quantity} has been remove from the list. ")
            return
    
    print(f"{item_to_remove} was not found in the list.")


def display_list(shopping_list):
    #Check if the list is empty
    if not shopping_list:
        print("Your shopping list is currently empty.")
    
    else:
        print("\nCurrent Shopping List: ")
        #Looping through the list:
        for item, quantity in shopping_list:
            print(f"{item}: {quantity}")


def sort_list(shopping_list):
    if not shopping_list:
        print("Your shopping list is empty, nothing to sort")
    else: 
        shopping_list.sort(key=lambda x: x[0].lower())
        print("The shopping list has been sorted alphabetically.")

def shopping_list_program():
    shopping_list = []

    while True: 
        display_menu()

        # User selects an option
        choice = input("Select an option (1-5): \n")

        if choice == '1':
            add_item(shopping_list)
        elif choice == '2':
            remove_item(shopping_list)
        elif choice == '3':
            display_list(shopping_list)
        elif choice == '4':
            sort_list(shopping_list)
        elif choice == '5':
            print("Exiting the shopping list program.")
            break
        else:
            print("Invalid option, please select between 1 - 5.")

# Start The shopping list program
shopping_list_program()



