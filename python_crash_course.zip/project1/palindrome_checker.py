import string

def palindrome_check(prompt):
    #Remove spaces,punctuation and convert to lowercase
   
    cleaned_text = ''.join(char.lower() for char in prompt if char not in string.punctuation and char != " ")

    # check if the cleaned text is the same forwards and backwards
    return cleaned_text == cleaned_text[::-1]


#Start Loop
while True:
# User input
    user_input = input("Enter a word or phrase to check if it's a palindrome: (or enter 'q' to quit) \n").lower()
   
    # Allow the user to quit the program
    if user_input.lower() == 'q':
        print("Thanks for playing the game. Goodbye!")
        break

    #Call the function with the user's input and display the result
    if palindrome_check(user_input):
        print(f"'{user_input}' is a palindrome.")
    else:
        print(f"'{user_input}' is not a palindrome.")
    
    