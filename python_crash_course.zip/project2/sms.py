import schedule
import time
from twilio.rest import Client
from datetime import datetime
import pytz

# Your Twilio credentials (replace with your actual credentials)
account_sid = "AC2d883912d815711d27a78b30dc4ea58f"
auth_token = "1a1e49ed276d0e325e3316eceb2c235d"
twilio_phone_number = "+12088259244"

# Your phone number (in international format, e.g., +63 for the Philippines)
my_phone_number = "+639263604277"  # Replace with your actual phone number

# Define the timezone (Philippine Time)
philippines_tz = pytz.timezone('Asia/Manila')

# Counter to keep track of the number of reminders sent
reminder_count = 0
max_reminders = 2  # Stop after 2 reminders

def send_sms_reminder():
    global reminder_count
    if reminder_count < max_reminders:
        # Get the current time in the Philippines
        current_time_ph = datetime.now(philippines_tz).strftime('2024-09-11 18:58:01')

        # Twilio Client initialization
        client = Client(account_sid, auth_token)

        # The message to be sent
        message_body = f"Reminder: Please create the song lineup for the Praise and Worship practice. Current time: {current_time_ph}"

        # Send the SMS
        message = client.messages.create(
            body=message_body,
            from_=twilio_phone_number,
            to=my_phone_number
        )
        
        # Increment the reminder count
        reminder_count += 1
        print(f"SMS sent successfully! Message SID: {message.sid}")
        print(f"Reminders sent: {reminder_count}/{max_reminders}")
        
        # If max reminders are reached, stop the script
        if reminder_count >= max_reminders:
            print("Maximum reminders sent. Stopping reminders.")
            return schedule.CancelJob
    else:
        print("No more reminders will be sent.")

# Schedule the job for 7:00 PM Philippine Time Monday to Friday
schedule.every().monday.at("19:00").do(send_sms_reminder)
schedule.every().tuesday.at("19:00").do(send_sms_reminder)
schedule.every().wednesday.at("19:00").do(send_sms_reminder)
schedule.every().thursday.at("19:00").do(send_sms_reminder)
schedule.every().friday.at("19:00").do(send_sms_reminder)

# Keep checking the schedule
while True:
    schedule.run_pending()
    time.sleep(60)  # Wait for 1 minute before checking again
