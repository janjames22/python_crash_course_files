import time
import sys

# Define the character to move
character = "O"
width = 50  # Set the width of the terminal space

# Infinite loop for continuous movement
while True:
    for x in range(width):  # Move from left to right
        # Clear the screen
        sys.stdout.write("\033[H\033[J")
        
        # Print spaces before the character to simulate movement
        sys.stdout.write(" " * x + character + "\n")
        
        # Flush the output to ensure it updates in the terminal
        sys.stdout.flush()
        
        # Control the speed of the movement
        time.sleep(0.05)
    
    for x in range(width, 0, -1):  # Move from right to left (bounce back)
        sys.stdout.write("\033[H\033[J")
        sys.stdout.write(" " * x + character + "\n")
        sys.stdout.flush()
        time.sleep(0.05)
