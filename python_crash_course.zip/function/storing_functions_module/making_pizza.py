from pizza import *

make_pizza(16, 'peperroni')
make_pizza(12, 'mushrooms', 'green peppers', 'extra cheese')
