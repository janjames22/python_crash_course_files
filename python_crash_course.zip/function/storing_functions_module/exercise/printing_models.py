import printing_functions as pf

pf.make_3dmodels('small', 'action figure')
pf.make_3dmodels('medium', 'action figure', 'ardiuno project casing', 'arduino project components')