def make_3dmodels(size, *model_types):
    """Summarize the 3d models we are about to make"""
    print(f"\nMaking a {size} 3d model for the engineering project with a model type:")
    for model_type in model_types:
        print(f"-{model_type}")