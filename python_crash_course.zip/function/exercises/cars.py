def make_car(manufacturer, model, **car_info):
    """Stores information about a car in a dictionary"""
    car_info['manufacturer'] = manufacturer
    car_info['model'] = model
    return car_info

# Calling the function with required information and additional keyword arguments
car = make_car('toyota', 'AE86', color= 'white and black', type='Front Engine and Front Wheel Drive')

#Printing the resulting dictionary
print(car)