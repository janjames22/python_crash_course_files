def make_sandwich(*items):
    """Making a sandwich that accepts a list of items a person wants"""
    print("\nMaking a sandwich with the following ingredients.")
    for item in items:
        print(f"-{item}")
    print("Your sandwich is ready\n")

# Calling the function three times with different number of arguments
make_sandwich('lettuce', 'tomato', 'cheese')
make_sandwich('ham', 'bacon', 'lettuce', 'mustard')
make_sandwich('turkey', 'avocado', 'spinach', 'mayo', 'pickles')
