class Car:
    """A simple attempt to represent a car."""

    def __init__(self, make, model, year, odometer_reading=0):
        """Iinitialize attributes to describe a car."""
        self.make = make
        self.model = model
        self.year = year
        self.odometer_reading = odometer_reading

    
    def get_descriptive_name(self):
        """Return a neatly formatted descriptive name."""
        long_name = f"\n{self.year} {self.make} {self.model}. "
        return long_name.title()
    
    def read_odometer(self):
        """Print a statement showing the car's mileage."""
        print(f"The odometer for this car is {self.odometer_reading} miles.")

    def updated_odometer(self, miles):
        """Set the odometer reading to the given value."""
        self.odometer_reading = miles
        

#creating an instances of Car class    
my_new_car = Car('audi', 'a4', 2019)
#printing methods get_descriptive_name
print(my_new_car.get_descriptive_name())

#Calling methods read_odometer
my_new_car.updated_odometer(23)
my_new_car.read_odometer()

