class Smartphone:
    """A simple attempt to represent a smartphone."""

    def __init__(self, brand, model, year, battery_health):
        """Initialize attributes to describe a smartphone."""
        self.brand = brand
        self.model = model
        self.year = year
        self.battery_life = battery_health

    def get_descriptive_name(self):
        """Return a neatly formatted descriptive name."""
        formatted_name = f"\nA {self.year}, {self.brand}, {self.model}, with battery remaining of only {self.battery_life}% ."
        return formatted_name.title()
    
    def check_battery(self):
        """"Print a stament showing the smarphone's battery level."""
        print(f"The battery life of {self.brand} is already {self.battery_life}.")

# Creating instances of the Smartphone Class
my_current_phone = Smartphone('POCO', 'X3 PRO', 2021, 80 )

# Printing methods get_descriptive_name
print(my_current_phone.get_descriptive_name())

#Calling methods check battery
my_current_phone.check_battery()

