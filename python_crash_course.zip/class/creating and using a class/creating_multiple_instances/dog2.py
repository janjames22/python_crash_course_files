class Dog:
    """A simple attempt to model a dog."""

    def __init__(self, name, age):
        """Initialize the name and age attributes."""
        self.name = name
        self.age = age
    
    def sit(self):
        """Simulate a dog sitting in a response to a command"""
        print(f"{self.name} is now sitting.")
    
    def roll_over(self):
        """Simulate a dog roll_over in a response to a commmand"""
        print(f"{self.name} is now rolling.")
    
my_dog = Dog('Lebron', 12)
your_dog = Dog('James', 11)

print(f"\nMy dog's name is {my_dog.name}.")
print(f"My dog is {my_dog.age} years old.")
my_dog.sit()

print(f"\nYour dog's name is {your_dog.name}.")
print(f"Your dog is {your_dog.age} years old")
your_dog.roll_over()
