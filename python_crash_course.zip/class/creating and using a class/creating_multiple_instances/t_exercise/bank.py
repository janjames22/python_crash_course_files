class Bank:
    def __init__(self, bank_name, location):
        """Initialize bank_name and Location attributes"""
        self.bank_name = bank_name
        self.location = location
    
    def describe_bank(self):
        """Print a message describing the bank."""
        print(f"\nThe bank: {self.bank_name} is located at {self.location}")
    
    def open_bank(self):
        """Print a message indicating that bank is open."""
        print(f"The bank: {self.bank_name} is now open!")

# Create instance of Bank Class
the_bank = Bank("Banko Sentral ng Pilipinas", "Cabanatuan City")

#Calling the methods on an instance
the_bank.describe_bank()
the_bank.open_bank()
