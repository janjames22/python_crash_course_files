class Library:
    def __init__(self, library_name, location):
        """Initialize library_name and location attributes."""
        self.library_name = library_name
        self.location = location
    
    def describe_library(self):
        """Print a message describing the library."""
        print(f"\nThe Library {self.library_name} is located at {self.location}")
    
    def open_library(self):
        """Print a message indicating the library is open."""
        print(f"The library {self.library_name} is now open!")

#Creating instances of Library Class:
my_library = Library("City Central Library", "Downtown")

#Call the methods on an instance
my_library.describe_library()
my_library.open_library()
