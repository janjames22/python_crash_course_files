class User:
    def __init__(self, first_name, last_name, age, location, email):
        """Initialize first_name, last_name, and other user profile attributes."""
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.location = location
        self.email = email
    
    def __repr__(self):
        return f"User({self.first_name}, {self.last_name}, {self.age}, {self.location}, {self.email})"
    
    def describe_user(self):
        """Prints a summary of the user's information"""
        print(f"\nUser Profile:")
        print(f"Name: {self.first_name} {self.last_name}" )
        print(f"Age: {self.age}")
        print(f"Location: {self.location}")
        print(f"email: {self.email}")

    def greet_user(self):
        """Prints a personalized greeting to the user."""
        print(f"\nHello {self.first_name} {self.last_name}! Welcome Back!")

#Creating an instances of the User Class
user1 = User("Jan James", "Graza", 26, "Malacanang", "janjamesgraza22@gmail.com")
user2 = User("Emily", "Johnson", 25, "Los Angeles", "emily.johnson@gmail.com")
user3 = User("Michael","Brown",  40, "Chicago", "michael.brown@gmail.com")

#Calling methods for each instances
for users in [user1, user2, user3]:
    users.describe_user()
    users.greet_user()
   