class Restaurant:
    def __init__(self,  restaurant_name, cuisine_type):
        """Initialize restaurant_name and cuisine_type attributes."""
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type

    def describe_restaurant(self):
        """Prints a message that describes the restaurant."""
        print(f"\nThe restaurant: {self.restaurant_name} offers {self.cuisine_type} cusine.")
    
    def open_restaurant(self):
        """Prints a message indicating the restaurant is open."""
        print(f"The restaurant: {self.restaurant_name} is now open!!")

# Creating an instance of the class
my_restaurant1 =Restaurant("James", "italian")
my_restaurant2 = Restaurant("Spicy Delight", "Indian")
my_restaurant3 = Restaurant("The Taco Spot", "Mexican")

# Calling methods on the instance
my_restaurant1.describe_restaurant()
my_restaurant1.open_restaurant()
my_restaurant2.describe_restaurant()
my_restaurant2.open_restaurant()
my_restaurant3.describe_restaurant()
my_restaurant3.open_restaurant()
